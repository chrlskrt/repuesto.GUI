package FoodOrderingSystem;

public class FoodOrderingSystem {
}
